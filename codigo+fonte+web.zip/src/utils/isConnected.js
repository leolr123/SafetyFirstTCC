const isConnected = localStorage.getItem('@todo/macaddress');

export default isConnected;