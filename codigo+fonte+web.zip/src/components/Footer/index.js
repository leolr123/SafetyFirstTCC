import React from 'react';
import * as S from './styles';

function Footer() {
  return (
    <S.Container>
     <span>ToDO - Organizando sua vida</span>
    </S.Container>
  )
}

export default Footer;
